
var i = 0;
var images = [];
var time = 3000;

images[0] = "advt_5.jpg";
images[1] = "advt_6.webp";
images[2] = "advt_7.jpg";
images[3] = "advt_8.jpg";

function changeImg() {
    document.slide.src = images[i];
    if (i < images.length - 1) {

        i++;
    } else {

        i = 0;
    }
    setTimeout("changeImg()", time);
}
window.onload = changeImg;

function search_job() {
    let input = document.getElementById('searchbar').value
    input = input.toLowerCase();
    let x = document.getElementsByClassName('job');

    for (i = 0; i < x.length; i++) {
        if (!x[i].innerHTML.toLowerCase().includes(input)) {
            x[i].style.display = "none";
        }
        else {
            x[i].style.display = "list-item";
        }

    }
}

function validate() {
    var email = document.getElementById("email").value;
    var comment = document.getElementById("comment").value;
    var emailout = document.getElementById("emailout");
    var commentout = document.getElementById("commentout");
    var submitout = document.getElementById("submitout");
    var message = " ";
    if (email.indexOf("@") == -1) {
        message = " Provide the Email";
        emailout.innerHTML = message;
    }
    if (comment.length < 50 || comment.length > 150) {
        message = " Minimum 50 Characters ";
        commentout.innerHTML = message;
    }
    if (message == " ") {
        submitout.innerHTML = "Thank You !!";
        return false;
    }
    else {
        return false;
    }
}