$(document).ready(function () {
    $.getJSON('./policy.json', function (data) {
        console.log(data);
        $.each(data, function (key, value) {
            $('#privacyContent').append(
                "<h3>" + value.heading + "</h3>"
            )
                .append(
                    "<p>" + value.content + "</p>"
                );
        });
    });
});
function information() {
    var str = "Thank you for your valuable feedback";
    document.getElementById("feedbackmessage").innerHTML = str;

}
function contactUsPage() {
    var str = "We are sorry please click on below link to ";
    document.getElementById("feedbackmessage").innerHTML = str;
    var mydiv = document.getElementById("feedbackmessage");
    var aTag = document.createElement('a');
    aTag.setAttribute('href', "contact.html");
    aTag.innerText = "reach us";
    mydiv.appendChild(aTag);
}





