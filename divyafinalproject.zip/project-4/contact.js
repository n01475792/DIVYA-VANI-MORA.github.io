function validate() {

    var name = document.getElementById("name").value;
    var email = document.getElementById("email").value;
    var phone = document.getElementById("phone").value;
    var sub = document.getElementById("subId").value;
    var query = document.getElementById("query").value;
    var nameout = document.getElementById("nameout");
    var emailout = document.getElementById("emailout");
    var phoneout = document.getElementById("phoneout");
    var queryout = document.getElementById("queryout");
    var subout = document.getElementById("subout");
    var message = " ";

    if (name == "") {
        message = " Provide the Name";
        nameout.innerHTML = message;
    }

    if (email.indexOf("@") == -1) {
        message = " Provide the Email";
        emailout.innerHTML = message;
    }

    if (phone.length != 10) {
        message = " Provide the Phone no";
        phoneout.innerHTML = message;

    }
    if (sub == "select option") {
        message = "Please select any option";
        subout.innerHTML = message;
    }

    if (query.length < 50 || query.length > 150) {
        message = " Minimum 50 Characters";
        queryout.innerHTML = message;

    }
    if (message == " ") {
        alert("Thanks for Submission");
    }
    else {
        return false;
    }
}
